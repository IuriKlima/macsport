"use client";

import { useState } from "react";
import { FileText, Download, ShieldCheck, Award } from "lucide-react";

export function ProductTabs({ descriptionLines, productName, pdfUrl, comoUsarImg }: { descriptionLines: string[], productName: string, pdfUrl?: string, comoUsarImg?: string }) {
  const [activeTab, setActiveTab] = useState("descricao");

  return (
    <div className="mt-16">
      <div className="flex border-b border-border mb-8 overflow-x-auto hide-scrollbar">
        <button 
          onClick={() => setActiveTab("descricao")}
          className={`px-6 py-4 whitespace-nowrap flex items-center gap-2 transition-colors ${activeTab === 'descricao' ? 'text-[#F5C400] border-b-2 border-[#F5C400] font-bold' : 'text-text-muted hover:text-foreground font-semibold'}`}
        >
          <FileText size={18} />
          DESCRIÇÃO COMPLETA
        </button>
        <button 
          onClick={() => setActiveTab("pdf")}
          className={`px-6 py-4 whitespace-nowrap flex items-center gap-2 transition-colors ${activeTab === 'pdf' ? 'text-[#F5C400] border-b-2 border-[#F5C400] font-bold' : 'text-text-muted hover:text-foreground font-semibold'}`}
        >
          <Download size={18} />
          BAIXAR PDF DO PRODUTO
        </button>
        <button 
          onClick={() => setActiveTab("garantia")}
          className={`px-6 py-4 whitespace-nowrap flex items-center gap-2 transition-colors ${activeTab === 'garantia' ? 'text-[#F5C400] border-b-2 border-[#F5C400] font-bold' : 'text-text-muted hover:text-foreground font-semibold'}`}
        >
          <ShieldCheck size={18} />
          GARANTIA
        </button>
        {comoUsarImg && (
          <button 
            onClick={() => setActiveTab("comousar")}
            className={`px-6 py-4 whitespace-nowrap flex items-center gap-2 transition-colors ${activeTab === 'comousar' ? 'text-[#F5C400] border-b-2 border-[#F5C400] font-bold' : 'text-text-muted hover:text-foreground font-semibold'}`}
          >
            <Award size={18} />
            COMO USAR
          </button>
        )}
      </div>

      <div className="bg-card-bg rounded-[2rem] p-8 border border-border min-h-[300px]">
        {activeTab === "descricao" && (
          <div className="animate-in fade-in duration-500">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Sobre o Equipamento</h3>
            <div className="prose prose-invert max-w-none text-text-muted">
              {descriptionLines.length > 0 ? descriptionLines.map((line: string, i: number) => (
                <p key={i} className="mb-4 leading-relaxed">{line}.</p>
              )) : (
                <p>Nenhuma descrição adicional disponível.</p>
              )}
            </div>
          </div>
        )}

        {activeTab === "pdf" && (
          <div className="animate-in fade-in duration-500 flex flex-col items-center justify-center py-10 text-center">
            <div className="w-20 h-20 bg-[#F5C400]/10 text-[#F5C400] rounded-full flex items-center justify-center mb-6">
              <Download size={40} />
            </div>
            <h3 className="text-2xl font-bold mb-4 text-foreground">Catálogo e Especificações Técnicas</h3>
            <p className="text-text-muted mb-8 max-w-lg">
              Faça o download do PDF completo com as especificações técnicas, medidas, peso, músculos trabalhados e dicas de biomecânica do {productName}.
            </p>
            {pdfUrl ? (
              <a href={pdfUrl} target="_blank" rel="noopener noreferrer" className="bg-[#F5C400] text-black font-bold px-8 py-3 rounded-[2rem] flex items-center gap-2 hover:bg-yellow-500 transition-colors">
                <Download size={20} />
                BAIXAR ARQUIVO PDF
              </a>
            ) : (
              <div className="bg-gray-100 text-gray-500 font-bold px-8 py-3 rounded-[2rem] flex items-center gap-2 cursor-not-allowed">
                <Download size={20} />
                PDF INDISPONÍVEL
              </div>
            )}
          </div>
        )}

        {activeTab === "garantia" && (
          <div className="animate-in fade-in duration-500">
            {/* Certificado de Garantia visual */}
            <div className="relative overflow-hidden bg-gradient-to-br from-gray-900 to-black border border-[#F5C400]/30 rounded-[2rem] p-8 md:p-12 shadow-2xl">
              {/* Marca d'água */}
              <div className="absolute -right-10 -bottom-10 opacity-5 pointer-events-none">
                <Award size={300} />
              </div>
              
              <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center">
                <div className="flex-shrink-0 w-32 h-32 bg-gradient-to-br from-[#F5C400] to-yellow-600 rounded-full flex items-center justify-center shadow-lg border-4 border-black">
                  <div className="text-center text-black">
                    <span className="block text-4xl font-black leading-none">5</span>
                    <span className="block text-xs font-bold uppercase tracking-widest">Anos</span>
                  </div>
                </div>
                
                <div>
                  <h3 className="text-3xl font-light text-white mb-2 flex items-center gap-3">
                    <Award className="text-[#F5C400]" size={32} />
                    Certificado de Garantia
                  </h3>
                  <div className="h-1 w-20 bg-[#F5C400] mb-6"></div>
                  
                  <p className="text-gray-300 mb-4 leading-relaxed text-lg">
                    A Macsport atesta a qualidade excepcional de seus produtos. O equipamento <strong className="text-white">{productName}</strong> possui cobertura total contra defeitos de fabricação em sua estrutura.
                  </p>
                  
                  <ul className="text-gray-400 space-y-2 font-medium">
                    <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-[#F5C400] rounded-full"></div> <strong>5 anos</strong> para estrutura principal (chassi).</li>
                    <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-[#F5C400] rounded-full"></div> <strong>1 ano</strong> para pintura e soldas.</li>
                    <li className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-[#F5C400] rounded-full"></div> <strong>6 meses</strong> para estofados, cabos, polias e rolamentos.</li>
                  </ul>
                  
                  <p className="text-xs text-gray-500 mt-6 mt-8">
                A Macsport oferece 3 anos de garantia estrutural para todos os equipamentos da linha {productName}. Cobrimos também defeitos de fabricação em estofados e peças móveis conforme o manual do proprietário.
              </p>
              <p>
                Para acionar a garantia, entre em contato com nosso suporte técnico informando o número de série do seu equipamento e a nota fiscal de compra.
              </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === "comousar" && comoUsarImg && (
          <div className="animate-in fade-in duration-500">
            <h3 className="text-2xl font-bold mb-6 text-foreground">Como Usar</h3>
            <div className="w-full rounded-[2rem] overflow-hidden border border-border">
              <img src={comoUsarImg} alt={`Como usar o ${productName}`} className="w-full h-auto object-contain" />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
