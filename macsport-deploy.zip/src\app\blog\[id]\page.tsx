import { getPostById, getPosts } from "@/lib/blog";
import { notFound } from "next/navigation";
import Link from "next/link";
import { Calendar, User, ChevronLeft } from "lucide-react";
import type { Metadata } from 'next';

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const post = await getPostById(resolvedParams.id);
  if (!post) {
    return {
      title: 'Post Não Encontrado | Macsport'
    };
  }

  return {
    title: `${post.titulo} | Macsport Blog`,
    description: post.resumo,
    openGraph: {
      title: `${post.titulo} | Macsport`,
      description: post.resumo,
      images: post.imagem ? [post.imagem] : [],
    },
  };
}

export default async function BlogPostPage({ params }: { params: Promise<{ id: string }> }) {
  const resolvedParams = await params;
  const post = await getPostById(resolvedParams.id);

  if (!post) {
    notFound();
  }

  // To display rich text content safely, we could use dangerouslySetInnerHTML if we had rich text.
  // For now, we assume post.conteudo exists, or we fallback to resumo.
  
  // Format content (if it's plain text with line breaks)
  const formatContent = (text: string) => {
    if (!text) return null;
    return text.split('\n').map((paragraph, idx) => (
      <p key={idx} className="mb-6 text-lg leading-relaxed">{paragraph}</p>
    ));
  };

  return (
    <main className="min-h-screen bg-background text-foreground pt-12 pb-24 px-4 md:px-8">
      <div className="max-w-4xl mx-auto">
        <Link href="/blog" className="inline-flex items-center gap-2 text-text-muted hover:text-[#F5C400] transition-colors mb-8 font-medium">
          <ChevronLeft size={20} />
          Voltar para o Blog
        </Link>
        
        <article className="bg-card-bg rounded-t-3xl rounded-b-none border border-border overflow-hidden shadow-sm">
          {post.imagem && (
            <div className="w-full h-[400px] md:h-[500px] relative">
              <img src={post.imagem} alt={post.titulo} className="w-full h-full object-cover" />
              <div className="absolute top-6 left-6 bg-[#F5C400] text-black px-4 py-1 text-sm font-bold uppercase rounded-t-3xl rounded-b-none shadow-md">
                {post.categoria}
              </div>
            </div>
          )}
          
          <div className="p-8 md:p-12">
            {!post.imagem && (
              <div className="bg-[#F5C400]/20 text-[#F5C400] px-4 py-1 text-sm font-bold uppercase rounded-t-3xl rounded-b-none w-fit mb-6 inline-block border border-[#F5C400]/50">
                {post.categoria}
              </div>
            )}
            
            <h1 className="text-3xl md:text-5xl font-bold mb-8 text-foreground leading-tight">
              {post.titulo}
            </h1>
            
            <div className="flex flex-wrap items-center gap-6 pb-8 border-b border-border mb-8 text-text-muted font-medium">
              <div className="flex items-center gap-2">
                <Calendar size={18} className="text-[#F5C400]" />
                {post.data}
              </div>
              <div className="flex items-center gap-2">
                <User size={18} className="text-[#F5C400]" />
                {post.autor}
              </div>
            </div>
            
            <div className="prose prose-invert max-w-none text-text-muted">
              {post.conteudo ? (
                // Use dangerouslySetInnerHTML se o conteúdo vier de um editor WYSIWYG
                <div dangerouslySetInnerHTML={{ __html: post.conteudo }} className="text-lg leading-relaxed text-text-muted [&>p]:mb-6 [&>h2]:text-2xl [&>h2]:font-bold [&>h2]:text-foreground [&>h2]:mt-10 [&>h2]:mb-4 [&>h3]:text-xl [&>h3]:font-bold [&>h3]:text-foreground [&>h3]:mt-8 [&>h3]:mb-4 [&>ul]:list-disc [&>ul]:pl-6 [&>ul]:mb-6 [&>ol]:list-decimal [&>ol]:pl-6 [&>ol]:mb-6 [&>li]:mb-2" />
              ) : (
                <>
                  <p className="text-xl font-medium text-foreground mb-8 italic border-l-4 border-[#F5C400] pl-6 py-2 bg-[#F5C400]/5 rounded-r-xl">
                    {post.resumo}
                  </p>
                  
                  {/* Mock content if post doesn't have real content yet */}
                  <p className="mb-6 text-lg leading-relaxed">
                    A escolha dos equipamentos corretos é fundamental para o sucesso do seu negócio fitness. 
                    Neste artigo, vamos explorar os principais aspectos que você deve considerar antes de realizar 
                    esse investimento crucial.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-foreground mt-10 mb-4">1. Entenda o perfil do seu público</h2>
                  <p className="mb-6 text-lg leading-relaxed">
                    Antes de comprar qualquer máquina, você precisa saber quem vai usá-la. Academias focadas em 
                    fisiculturismo precisam de pesos livres pesados e máquinas de musculação isoladas robustas. 
                    Por outro lado, studios de treinamento funcional focarão mais em espaço livre, kettlebells, 
                    dumbbells e estruturas de cross.
                  </p>
                  
                  <h2 className="text-2xl font-bold text-foreground mt-10 mb-4">2. Durabilidade e Engenharia</h2>
                  <p className="mb-6 text-lg leading-relaxed">
                    Equipamentos de academia sofrem desgaste extremo. O uso contínuo, suor e impacto diário exigem 
                    uma estrutura reforçada. Ao escolher seus equipamentos, verifique a espessura dos tubos de aço, 
                    a qualidade das soldas e, principalmente, o sistema de polias e cabos.
                  </p>
                  <p className="mb-6 text-lg leading-relaxed">
                    A Macsport orgulha-se da sua engenharia brasileira, desenvolvida especificamente para suportar 
                    a rotina intensa das academias nacionais, com manutenção facilitada e peças de reposição acessíveis.
                  </p>

                  <div className="bg-black border border-border rounded-t-3xl rounded-b-none p-8 my-10 text-center">
                    <h3 className="text-2xl font-bold text-[#F5C400] mb-4">Pronto para montar sua academia?</h3>
                    <p className="text-text-muted mb-6">Fale com nossos especialistas e solicite um projeto 3D gratuito.</p>
                    <Link href="/orcamento" className="inline-block bg-[#F5C400] text-black font-bold px-8 py-3 rounded-t-3xl rounded-b-none hover:bg-yellow-500 transition-colors">
                      SOLICITAR ORÇAMENTO
                    </Link>
                  </div>
                </>
              )}
            </div>
          </div>
        </article>
      </div>
    </main>
  );
}
